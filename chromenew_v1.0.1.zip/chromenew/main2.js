function set1(e){
document.querySelectorAll('img.segment')[e-1].src="clocknumber1/1.png";
}
function set2(e){
document.querySelectorAll('img.segment')[e-1].src="clocknumber1/2.png"}
function set3(e){
document.querySelectorAll('img.segment')[e-1].src="clocknumber1/3.png"}
function set4(e){
document.querySelectorAll('img.segment')[e-1].src="clocknumber1/4.png"}
function set5(e){
document.querySelectorAll('img.segment')[e-1].src="clocknumber1/5.png"}
function set6(e){
document.querySelectorAll('img.segment')[e-1].src="clocknumber1/6.png"}
function set7(e){
document.querySelectorAll('img.segment')[e-1].src="clocknumber1/7.png"}
function set8(e){
document.querySelectorAll('img.segment')[e-1].src="clocknumber1/8.png"}
function set9(e){
document.querySelectorAll('img.segment')[e-1].src="clocknumber1/9.png"}
function set0(e){
document.querySelectorAll('img.segment')[e-1].src="clocknumber1/0.png"}
function setcolon(){Array.from(document.getElementById('colon').children).forEach((el)=>{el.setAttribute('class','light_on')})}
function set(n,e){
switch(n){
case 0:set0(e);break;
case 1:set1(e);break;
case 2:set2(e);break;
case 3:set3(e);break;
case 4:set4(e);break;
case 5:set5(e);break;
case 6:set6(e);break;
case 7:set7(e);break;
case 8:set8(e);break;
case 9:set9(e);break;
default:break;
}
}
window.onload=()=>{
time=120;
setInterval(function(){setcolon();date=new Date();set(Math.floor(date.getHours()/10),1);set(date.getHours()%10,2);set(Math.floor(date.getMinutes()/10),3);set(date.getMinutes()%10,4);set(Math.floor(date.getSeconds()/10),5);set(date.getSeconds()%10,6)},100)
}
window.addEventListener("keydown",(e)=>{
    window.parent.postMessage("{\"key\":\""+e.key+"\",\"altKey\":"+e.altKey+"}");
})