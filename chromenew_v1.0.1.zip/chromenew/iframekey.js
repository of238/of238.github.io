window.addEventListener("keydown",(e)=>{
    window.parent.postMessage("{\"key\":\""+e.key+"\",\"altKey\":"+e.altKey+"}");
})