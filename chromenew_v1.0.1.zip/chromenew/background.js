chrome.runtime.onMessage.addListener((message,s,sendResponse)=>{
    fetch("https://www.google.co.jp/complete/search?client=opera&q="+encodeURIComponent(message.word)).then(
        (e)=>{return e.text()}
    ).then((e)=>{
        sendResponse(e)
    }
    );
    return true;
}
)