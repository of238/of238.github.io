window.addEventListener("load",()=>{
    b=1;a=0;i=setInterval(function(){a++;s.innerHTML=a;s.innerHTML=Number(s.innerHTML) % 60;m.innerHTML=Math.floor(a/60);m.innerHTML=Number(m.innerHTML) % 60;h.innerHTML=Math.floor(a/3600);if(s.innerHTML.length==1)s.innerHTML=0+s.innerHTML;if(m.innerHTML.length==1)m.innerHTML=0+m.innerHTML;if(h.innerHTML.length==1)h.innerHTML=0+h.innerHTML},1000);
    startbutton.addEventListener("click",()=>{
        if(b==1)return;b=1;i=setInterval(function(){a++;s.innerHTML=a;s.innerHTML=Number(s.innerHTML) % 60;m.innerHTML=Math.floor(a/60);m.innerHTML=Number(m.innerHTML) % 60;h.innerHTML=Math.floor(a/3600);if(s.innerHTML.length==1)s.innerHTML=0+s.innerHTML;if(m.innerHTML.length==1)m.innerHTML=0+m.innerHTML;if(h.innerHTML.length==1)h.innerHTML=0+h.innerHTML},1000)
    });
    resetbutton.addEventListener("click",()=>{
        b=0;clearInterval(i);a=0;s.innerHTML=m.innerHTML=h.innerHTML="00"
    });
    stopbutton.addEventListener("click",()=>{
        b=0;clearInterval(i);
    })
    fullscreenbutton.addEventListener("click",()=>{
        if(document.fullscreenElement==null){document.documentElement.requestFullscreen();}else{document.exitFullscreen()}
    });
    resetbutton.click();
})