window.addEventListener("DOMContentLoaded",()=>{
    list=document.getElementById("list");
    inputbox=document.getElementById("inputbox");
    inputbox.addEventListener("keyup",(e)=>{
        if(e.key=="Enter"){
            e.preventDefault();
            window.open("https://www.google.com/search?q="+encodeURIComponent(e.target.value),"_self")
        }else{
            chrome.runtime.sendMessage({word:(e.target.value || ""),type:"search"}).then(e=>{j=JSON.parse(e);if(j[0]!="")j[1].unshift(j[0]+"<span class='graytext'> - Google検索</span>");j=Array.from(new Set(j[1]));list.style.height=list.length*20+"px";list.innerHTML=j.map(e=>{return "<a style='text-decoration:none;color:black;display:block;display:flex;align-items:center;height:44px;' href='https://www.google.com/search?q="+e.replace(/<span.+/,"")+"' class='matches' title=''><div style='display:block;margin:20px;margin-right:12px;width:20px;height:20px;-webkit-mask-repeat:no-repeat;-webkit-mask-size:100%;-webkit-mask-image: url(icon_search.svg);background-color:gray'></div><div style='background-color:transparent'>"+e+"</div></a>"}).join("")});
        }
    },false)
    inputbox.addEventListener("focus",(e)=>{
        focus=false;mouse=false;
        chrome.runtime.sendMessage({word:(e.target.value || "あ"),type:"search"}).then(e=>{j=JSON.parse(e)[1];list.style.height=list.length*20+"px";list.innerHTML=j.map(e=>{return "<a style='margin:0;text-decoration:none;color:black;display:flex;align-items:center;height:44px;' href='https://www.google.com/search?q="+e+"' class='matches' title=''><div style='display:block;margin:20px;margin-right:12px;width:20px;height:20px;-webkit-mask-repeat:no-repeat;-webkit-mask-size:100%;-webkit-mask-image: url(icon_search.svg);background-color:gray'></div><div style='background-color:transparent'>"+e+"</div></a>"}).join("")});
    })
    inputbox.addEventListener("input",(e)=>{
        if(e.target.value==""){return;}
        chrome.runtime.sendMessage({word:(e.target.value || ""),type:"search"}).then(e=>{j=JSON.parse(e);if(j[0]!="")j[1].unshift(j[0]+"<span class='graytext'> - Google検索</span>");j=Array.from(new Set(j[1]));list.style.height=list.length*20+"px";list.innerHTML=j.map(e=>{return "<a style='text-decoration:none;color:black;display:block;display:flex;align-items:center;height:44px;' href='https://www.google.com/search?q="+e.replace(/<span.+/,"")+"' class='matches' title=''><div style='display:block;margin:20px;margin-right:12px;width:20px;height:20px;-webkit-mask-repeat:no-repeat;-webkit-mask-size:100%;-webkit-mask-image: url(icon_search.svg);background-color:gray'></div><div style='background-color:transparent'>"+e+"</div></a>"}).join("")});
    })
    inputbox.addEventListener("blur",()=>{
        if(mouse==false&&focus==false)list.innerHTML="";
    })
    inputbox.addEventListener("keydown",()=>{
        focus=true;
    },false)
    list.addEventListener("mouseover",()=>{
        mouse=true;
    });
    list.addEventListener("focus",()=>{
        focus=true;
    });
    list.addEventListener("blur",()=>{
        focus=false;
    });
    list.addEventListener("mouseleave",()=>{
        mouse=false;
    });
});