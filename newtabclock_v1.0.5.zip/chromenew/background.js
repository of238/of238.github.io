chrome.runtime.onMessage.addListener((message,s,sendResponse)=>{
    if(message.type=="search"){
    fetch("https://www.google.co.jp/complete/search?client=opera&q="+encodeURIComponent(message.word)).then(
        (e)=>{return e.text()}
    ).then((e)=>{
        sendResponse(e)
    }
    );}
    if(message.type=="getstoragelocal"){
        chrome.storage.local.get(message.key,(v)=>{sendResponse(v)});
    }
    if(message.type=="setstoragelocal"){
        var key=message.key;
        chrome.storage.local.set({key:message.value},()=>{sendResponse("ok")});
    }
    if(message.type=="getstoragesync"){
        chrome.storage.sync.get(message.key,(v)=>{sendResponse(v)});
    }
    if(message.type=="setstoragesync"){
        var key=message.key;
        chrome.storage.sync.set({key:message.value},()=>{sendResponse("ok")});
    }
    return true;
}
)